Group Members: Yen-Cheng Wu & Pulkit Kakkar

The client-api, client and server, relies on the simplified rpc library provided along with the assignment.
The client program will need to use the remote_client_call function to run any server side functions.

After unziping, one should run make and generate the libclient-api.a